package com.viewnext.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

@Service  // Genera un bean y lo mete en el contenedor
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired
	private ProductosDAO dao;  // Inyeccion de dependencias DI

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
