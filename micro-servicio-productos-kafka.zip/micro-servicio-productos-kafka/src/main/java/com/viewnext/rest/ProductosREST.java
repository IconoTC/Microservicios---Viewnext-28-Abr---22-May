package com.viewnext.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.IProductosBS;
import com.viewnext.kafka.Productor;
import com.viewnext.models.Producto;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RefreshScope
@RestController
public class ProductosREST {
	
	@Autowired
	private Productor productor;
	
	// Inyectar el valor de la propiedad recuperado del servidor de configuracion
	@Value("${configuracion.modo}")
	private String texto;
	
	// Con puerto dinamico esto no funciona
	// @Value("${server.port}")
	// private Integer port;
	
	// Otra alternativa es inyectar la peticion
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/enviar/2/mensaje/Producto de calidad y barato
	@GetMapping("/enviar/{id}/mensaje/{mensaje}")
	public void envios(@PathVariable(name = "id") Long id, @PathVariable String mensaje) {
		Producto producto = bs.buscarProducto(id);
		String comentario = mensaje + " del producto " + producto;
		productor.enviarComentario(comentario);
	}
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	@Operation(summary = "listar productos", description = "Retorna una lista de productos")
	@ApiResponse(responseCode = "200", description = "Respuesta listar OK")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	@Operation(summary = "buscar productos", description = "Retorna el producto buscado")
	@ApiResponse(responseCode = "200", description = "Respuesta buscar OK")
	public Producto buscar(@PathVariable(name = "id") Long id) throws InterruptedException {
		
		// Mostrar el modo de configuracion
		System.out.println("************************* " + texto);
		
		Producto producto = bs.buscarProducto(id);
		
		// Si no encontramos el producto, lanzaremos una excepcion
		if (producto.getDescripcion() == null) {
			throw new RuntimeException("Error al buscar el producto");
		}
		
		// Probar las peticiones lentas
		if (id == 5L) {
			Thread.sleep(5000);
		}
		
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
