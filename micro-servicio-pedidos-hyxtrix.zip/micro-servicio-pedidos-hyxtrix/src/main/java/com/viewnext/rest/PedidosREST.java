package com.viewnext.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.viewnext.business.IPedidosBS;
import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@RestController
public class PedidosREST {
	
	@Autowired
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/2/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	@HystrixCommand(fallbackMethod = "manejarError")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El metodo alternativo ha de tener los mismos argumentos + Throwable
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "*********************");
		System.out.println(ex.getClass() + "-----------------");
		
		Producto producto = new Producto(id, "Producto vacio", 0, null);
		return new Pedido(producto,cantidad);
	}

}
