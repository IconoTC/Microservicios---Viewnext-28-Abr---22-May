package com.viewnext.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.viewnext.models.Pedido;
import com.viewnext.models.Producto;

@Service
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
//		Producto producto = restTemplate.getForObject(
//				"http://localhost:8001/buscar/{id}", Producto.class, id);
		
		// Ahora con Eureka no necesitamos saber la url del servicio de productos
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{id}", Producto.class, id);
		
		// Crear el pedido y retornarlo
		Pedido pedido = new Pedido(producto, cantidad);	
		return pedido;
	}

}
