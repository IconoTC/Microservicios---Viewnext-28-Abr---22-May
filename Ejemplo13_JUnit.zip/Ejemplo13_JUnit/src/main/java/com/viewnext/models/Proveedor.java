package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

public class Proveedor {
	
	private List<Producto> productos;
	private String nombre;
	
	public Proveedor() {
		productos = new ArrayList<>();
	}
	
	public void addProducto(Producto producto) {
		productos.add(producto);
		producto.setProveedor(this);
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Proveedor [productos=" + productos + ", nombre=" + nombre + "]";
	}
	
}
