package com.viewnext.models;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

import com.viewnext.utils.PrecioNegativoException;

public class ProductoTest {
	
	Producto producto;
	
	@BeforeAll
	// Debe ser estatico
	static void inicioClasePrueba() {
		// Abrir un recurso fichero, log, ... donde guardar los resultados de las pruebas
		System.out.println("Empezamos a probar la clase ProductoTest");
	}
	
	@AfterAll
	// Debe ser estatico
	static void finClasePrueba() {
		// Cerrar el recurso abierto
		System.out.println("Terminamos de probar la clase ProductoTest");
	}
	
	@BeforeEach
	void inicioMetodoTest() {
		producto = new Producto(1, "Impresora", 129.95);
		System.out.println("Producto creado para realizar la prueba");
	}
	
	@AfterEach
	void finalMetodoTest() {
		System.out.println("Prueba terminada");
	}
	
	@Nested
	@DisplayName("Probando los test de la clase Producto")
	class ProductoPruebas{
		
		@Test
		@DisplayName("Probando la descripcion del producto")
		void testDescripcion() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			String descripcionReal = producto.getDescripcion();
			String descripcionEsperada = "Impresora";
			Assertions.assertEquals(descripcionEsperada, descripcionReal);
		}
		
		@Test
		@DisplayName("Probando el precio del producto")
		void testPrecio() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			// Assertions.assertTrue(producto.getPrecio() > 0);
			Assertions.assertFalse(producto.getPrecio() <= 0);
		}
		
		@Test
		@DisplayName("Probando la igualdad de productos")
		@Disabled
		void testIgualdadProductos() {
			//Producto producto = new Producto(1, "Impresora", 129.95);
			Producto producto2 = new Producto(1, "Impresora", 129.95);
			Assertions.assertEquals(producto, producto2);
		}
		
		@Test
		void testPrecioNegativoException() {
			
			// Comprobar que lanza la excepcion al ser el precio negativo
			Exception exception = Assertions.assertThrows(PrecioNegativoException.class, () -> {
				producto.setPrecio(-10);
			});
			
			// Comprobar el mensaje de la excepcion
			String msgReal = exception.getMessage();
			String msgEsperado = "El precio no puede ser negativo";
			Assertions.assertEquals(msgEsperado, msgReal);
		}	
	}
	
	@Nested
	@DisplayName("Probando los test de la clase proveedor")
	class ProveedorPruebas{
		
		@Test
		void testRelaccionProductoProveedor() {
			Producto producto2 = new Producto(2, "Scanner", 237.50);
			
			Proveedor proveedor = new Proveedor();
			proveedor.setNombre("HP");
			proveedor.addProducto(producto);
			proveedor.addProducto(producto2);
			
//			Assertions.assertNotNull(proveedor.getProductos());
//			Assertions.assertEquals(2, proveedor.getProductos().size(), "El proveedor debe tener 2 productos"); 
//			
//			// El proveedor tiene un producto Impresora
//			Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
//					.filter(prod -> prod.getDescripcion().equals("Impresora"))
//					.findFirst()
//					.get()
//					.getDescripcion());
			
			// Agrupar todas las aserciones
			Assertions.assertAll(
					() -> Assertions.assertNotNull(proveedor.getProductos()),
					() -> Assertions.assertEquals(2, proveedor.getProductos().size(), "El proveedor debe tener 2 productos"),
					() -> Assertions.assertEquals("Impresora", proveedor.getProductos().stream()
							.filter(prod -> prod.getDescripcion().equals("Impresora"))
							.findFirst()
							.get()
							.getDescripcion())
			);
		}		
	}
	
	@Nested
	@DisplayName("Habilitar o deshabilitar pruebas segun SO, JRE")
	class SO_JRE{
		
		@Test
		@EnabledOnOs(OS.WINDOWS)
		void testSOWindows() {
			System.out.println("Se ejecuta si el SO es Windows");
		}
		
		@Test
		@EnabledOnOs({OS.MAC, OS.LINUX})
		void testSOMacLinux() {
			System.out.println("Se ejecuta si el SO es Mac o Linux");
		}
		
		@Test
		@DisabledOnOs(OS.WINDOWS)
		void testNoSOWindows() {
			System.out.println("Deshabilitado si el SO es Windows");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_8)
		void testSoloJava8() {
			System.out.println("Probando test en Java 8");
		}
		
		@Test
		@DisabledOnJre(JRE.JAVA_8)
		void testNoJava8() {
			System.out.println("Deshabilitado test en Java 8");
		}
		
		@Test
		@EnabledOnJre(JRE.JAVA_21)
		void testSoloJava21() {
			System.out.println("Probando test en Java 21");
		}
	}

}






















