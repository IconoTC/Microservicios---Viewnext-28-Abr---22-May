package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

import com.viewnext.business.PruebaCacheBS;

@SpringBootApplication
// Habilitar la cache
@EnableCaching
public class Ejemplo19SpringCacheApplication implements CommandLineRunner{
	
	@Autowired
	private PruebaCacheBS bs;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo19SpringCacheApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Numero: " + bs.hallarNumero());	
		System.out.println("Numero: " + bs.hallarNumero());	
		System.out.println("Numero: " + bs.hallarNumero());	
		System.out.println("Numero: " + bs.hallarNumero());	
		System.out.println("Numero: " + bs.hallarNumero());	
	}

}
