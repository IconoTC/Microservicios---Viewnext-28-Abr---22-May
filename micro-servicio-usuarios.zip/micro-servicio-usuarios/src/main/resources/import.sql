INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$VLSuQtVuF4tsotzmmmBj4eaimwwLzbR9wUyzaEK6m/rhlfTEJt8Cu', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$bt01nrrH6UL9TsNJeroBbucsWZ00s3VIfB.HejZzdHLJybGkOeiF2', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);