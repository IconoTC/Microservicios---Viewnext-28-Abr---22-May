package com.viewnext.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Valoracion;

@RepositoryRestResource(collectionResourceRel = "VALORACIONES", path = "valoraciones")
public interface ValoracionesDAO extends JpaRepository<Valoracion, Integer>{

	// Consultar todas las valoraciones
	// http://localhost:8014/valoraciones
}
