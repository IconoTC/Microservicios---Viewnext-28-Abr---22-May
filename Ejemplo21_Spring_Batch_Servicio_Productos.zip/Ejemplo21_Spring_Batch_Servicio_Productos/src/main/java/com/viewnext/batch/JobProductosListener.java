package com.viewnext.batch;

import java.util.List;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.viewnext.models.Producto;

@Component
public class JobProductosListener extends JobExecutionListenerSupport{
	
	private long inicio;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			List<Producto> lista = jdbcTemplate.query("select * from productos", 
					(resultSet,row) -> new Producto(
							resultSet.getInt("id"), 
							resultSet.getString("descripcion"), 
							resultSet.getDouble("precio")));
			
			lista.forEach(System.out::println);
		}
		
		System.out.println("Finalizando el proceso Job ------------------------");
		
		// Tomar el tiempo final
		long fin = System.currentTimeMillis();
		System.out.println("Tiempo de ejecucion: " + (fin - inicio) + " mseg.");
	}
	
	@Override
	public void beforeJob(JobExecution jobExecution) {
		// Tomar el tiempo de inicio
		inicio = System.currentTimeMillis();
		
		System.out.println("Iniciando el proceso Job ------------------------");
	}

}
