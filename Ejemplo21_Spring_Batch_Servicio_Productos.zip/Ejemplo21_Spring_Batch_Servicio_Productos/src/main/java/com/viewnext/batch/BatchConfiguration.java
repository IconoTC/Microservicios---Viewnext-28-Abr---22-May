package com.viewnext.batch;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import com.viewnext.models.Producto;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	// Crear un job
	@Bean
	public Job crearJob(JobProductosListener jobProductosListener, Step step1) {
		return jobBuilderFactory.get("productosJob")
				.incrementer(new RunIdIncrementer())
				.listener(jobProductosListener)
				.flow(step1)
				.end()
				.build();
	}
	
	// Crear un step
	@Bean
	public Step step1(JdbcBatchItemWriter<Producto> writer) {
		return stepBuilderFactory.get("step1")
				.<Producto,Producto>chunk(5)
				.reader(reader())
				.processor(proceso())
				.writer(writer)
				.build();		
	}
	
	// Crear el processor
	@Bean
	public ProductoJob proceso() {
		return new ProductoJob();
	}
	
	// Crear el reader
	@Bean
	public FlatFileItemReader<Producto> reader(){
		return new FlatFileItemReaderBuilder<Producto>()
				.name("productoItemReader")
				.resource(new ClassPathResource("data.csv"))
				.delimited()
				.names(new String[] {"id","descripcion","precio"})
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Producto>() {
					{
						setTargetType(Producto.class);
					}
				})
				.build();
	}
	
	
	// Crear el writer
	@Bean
	public JdbcBatchItemWriter<Producto> writer(DataSource dataSource){
		return new JdbcBatchItemWriterBuilder<Producto>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO productos (id,descripcion,precio) VALUES (:id, :descripcion, :precio)")
				.dataSource(dataSource)
				.build();
	}

}












