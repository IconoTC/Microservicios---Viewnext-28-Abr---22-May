package com.viewnext.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Direccion implements Serializable{
	
	private String calle;
	private String localidad;
	
	@Column(name = "codigo_postal")
	private int cp;
	
	public Direccion() {
		// TODO Auto-generated constructor stub
	}

	public Direccion(String calle, String localidad, int cp) {
		super();
		this.calle = calle;
		this.localidad = localidad;
		this.cp = cp;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public int getCp() {
		return cp;
	}

	public void setCp(int cp) {
		this.cp = cp;
	}

	@Override
	public String toString() {
		return "Direccion [calle=" + calle + ", localidad=" + localidad + ", cp=" + cp + "]";
	}
	
	

}
