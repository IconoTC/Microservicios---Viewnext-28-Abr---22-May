package com.viewnext;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.viewnext.models.Alumno;
import com.viewnext.models.Persona;
import com.viewnext.models.Profesor;

public class AppMain {
	
	public static void main(String[] args) {
		// 1.- EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// 2.- EntityManager es el eje central de JPA
		EntityManager em = emf.createEntityManager();  // En este momento se abre la conexion a la BBDD
		
		// 3.- Obtener una transaccion
		EntityTransaction et = em.getTransaction();
		
		// 4.- Crear instancias de Persona
		Persona persona = new Persona("Pedro", "Lopez");	
		Alumno alumno = new Alumno("Maria", "Rodriguez", "Microservicios");
		Profesor profesor = new Profesor("Juan", "Sanchez", "Ingeniero Teleco");
		
		try {
			et.begin();
			
			em.persist(persona);
			em.persist(alumno);
			em.persist(profesor);
			
			et.commit();
			
			System.out.println(persona);
			System.out.println(alumno);
			System.out.println(profesor);
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Nos aseguramos de cerrar la conexion
			em.close();
		}
	}

}
