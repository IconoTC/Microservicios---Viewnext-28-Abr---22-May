package com.viewnext.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.viewnext.models.Producto;

public class ProductosDAO {
	
	// crear una lista estatica con 5 productos
	private static List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Scanner", 140.50),
			new Producto(3, "Teclado", 35.0),
			new Producto(4, "Raton", 22.0),
			new Producto(5, "Impresora", 87.30));
	
	
	public Optional<Producto> buscar(int id){
		for (Producto producto : lista) {
			if (producto.getId() == id) {
				return Optional.of(producto);
			}
		}
		
		return Optional.empty();
	}

}
