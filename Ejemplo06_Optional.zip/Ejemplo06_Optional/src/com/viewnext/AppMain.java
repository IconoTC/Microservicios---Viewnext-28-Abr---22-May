package com.viewnext;

import java.util.Optional;

import com.viewnext.models.Producto;
import com.viewnext.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		System.out.println(dao.buscar(2).get());
		
		// java.util.NoSuchElementException:
		// System.out.println(dao.buscar(25667).get());
		
		Optional<Producto> opProd = dao.buscar(25667);
		if (opProd.isPresent()){
			System.out.println(opProd.get());
		}
		
		if (opProd.isEmpty()) {
			System.out.println("Ese producto no existe en nuestro catalogo");
		}
		
		System.out.println(opProd.orElse(new Producto()));
		
		opProd.orElseThrow();

	}

}
