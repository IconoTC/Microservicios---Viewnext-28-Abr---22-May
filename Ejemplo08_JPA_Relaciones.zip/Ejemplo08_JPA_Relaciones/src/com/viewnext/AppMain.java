package com.viewnext;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.viewnext.models.Coche;
import com.viewnext.models.Nif;
import com.viewnext.models.Persona;
import com.viewnext.models.Telefono;

public class AppMain {
	
	public static void main(String[] args) {
		// 1.- EntityManagerFactory
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		// 2.- EntityManager es el eje central de JPA
		EntityManager em = emf.createEntityManager();  // En este momento se abre la conexion a la BBDD
		
		// 3.- Obtener una transaccion
		EntityTransaction et = em.getTransaction();
		
		// 4.- Crear los nifs
		Nif n1 = new Nif('A', 1111111L);
		Nif n2 = new Nif('B', 2222222L);
		Nif n3 = new Nif('C', 3333333L);
		
		// 5.- Crear telefonos
		Telefono t1 = new Telefono(616111111L);
		Telefono t2 = new Telefono(616222222L);
		Telefono t3 = new Telefono(616333333L);
		Telefono t4 = new Telefono(616444444L);
		Telefono t5 = new Telefono(616555555L);
		Telefono t6 = new Telefono(616666666L);
		
		// 6.- Crear coches
		Coche c1 = new Coche("1111-MRX", "A3");
		Coche c2 = new Coche("2222-MRX", "A4");
		Coche c3 = new Coche("3333-MRX", "A5");
		Coche c4 = new Coche("4444-MRX", "A6");
		
		// 7.- Crear instancias de Persona
		Persona p1 = new Persona("Pedro", n1);	
		Persona p2 = new Persona("Maria", n2);
		Persona p3 = new Persona("Juan", n3);
		
		// 8.- Asignar los telefonos
		p1.addTelefono(t1);
		p1.addTelefono(t2);
		p2.addTelefono(t3);
		p2.addTelefono(t4);
		p3.addTelefono(t5);
		p3.addTelefono(t6);
		
		// 9.- Asignar los coches
		p1.addCoche(c1);
		p1.addCoche(c2);
		p1.addCoche(c3);
		
		p2.addCoche(c2);
		p2.addCoche(c3);
		p2.addCoche(c4);
		
		p3.addCoche(c1);
		p3.addCoche(c4);
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
			
			System.out.println(p1);
			System.out.println(p2);
			System.out.println(p3);
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Nos aseguramos de cerrar la conexion
			em.close();
		}
	}

}
