package com.viewnext.models;

import java.util.ArrayList;
import java.util.List;

public class Persona {
	
	private String nombre;
	private List<Viaje> listaViajes = new ArrayList<>();
	
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nombre) {
		super();
		this.nombre = nombre;
	}
	
	public void addViaje(Viaje viaje) {
		listaViajes.add(viaje);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Viaje> getListaViajes() {
		return listaViajes;
	}

	public void setListaViajes(List<Viaje> listaViajes) {
		this.listaViajes = listaViajes;
	}

	@Override
	public String toString() {
		return "Persona [nombre=" + nombre + ", listaViajes=" + listaViajes + "]";
	}
	
	

}
