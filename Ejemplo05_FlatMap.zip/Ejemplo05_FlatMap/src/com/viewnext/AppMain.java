package com.viewnext;

import java.util.Arrays;
import java.util.List;

import com.viewnext.models.Persona;
import com.viewnext.models.Viaje;

public class AppMain {
	
	/*
	 * flatMap permite aplanar estructuras de datos anidadas,
	 * como listas que contienen dentro otras listas
	 * Es util para evitar dobles bucles anidados y procesar
	 * todos los datos de forma conjunta
	 * */

	public static void main(String[] args) {
		
		Persona juan = new Persona("Juan");
		juan.addViaje(new Viaje("Italia"));
		juan.addViaje(new Viaje("Francia"));
		juan.addViaje(new Viaje("Alemania"));
		
		Persona maria = new Persona("Maria");
		maria.addViaje(new Viaje("Portugal"));
		maria.addViaje(new Viaje("Brasil"));
		
		List<Persona> personas = Arrays.asList(juan, maria);
		
		// Que paises han visitado entre los 2
		for (Persona p : personas) {
			for (Viaje v : p.getListaViajes()) {
				System.out.println(v.getPais());
			}
		}
		System.out.println("---------------------");
		
		// Utilizando flatMap
		personas.stream()
			.flatMap(p -> p.getListaViajes().stream())
			.map(v -> v.getPais())
			.forEach(System.out::println);
		System.out.println("---------------------");
		

	}

}
