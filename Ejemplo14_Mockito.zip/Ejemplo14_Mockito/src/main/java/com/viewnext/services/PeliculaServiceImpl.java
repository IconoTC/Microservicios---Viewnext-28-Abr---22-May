package com.viewnext.services;

import java.util.List;
import java.util.Optional;

import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepository;
import com.viewnext.repositories.PeliculaRepository;

public class PeliculaServiceImpl implements PeliculaService {

	private PeliculaRepository peliculaRepository;
	private ActorRepository actorRepository;

	public PeliculaServiceImpl(PeliculaRepository peliculaRepository, ActorRepository actorRepository) {
		super();
		this.peliculaRepository = peliculaRepository;
		this.actorRepository = actorRepository;
	}

	@Override
	public Pelicula findPeliculaByNombre(String nombre) {
		Optional<Pelicula> peliculaOpt = peliculaRepository.findAll().stream()
				.filter(peli -> peli.getNombre().contains(nombre)).findFirst();

		Pelicula pelicula = null;
		if (peliculaOpt.isPresent()) {
			pelicula = peliculaOpt.orElseThrow(() -> new RuntimeException("Pelicula no encontrada"));
		}
		return pelicula;
	}

	@Override
	public Pelicula findPeliculaByNombreConActores(String nombre) {
		Pelicula pelicula = findPeliculaByNombre(nombre);
		
		if (pelicula != null) {
			List<String> reparto = actorRepository.findActoresByPelicula(pelicula.getId());
			pelicula.setActores(reparto);
		}
		
		return pelicula;
	}

}


