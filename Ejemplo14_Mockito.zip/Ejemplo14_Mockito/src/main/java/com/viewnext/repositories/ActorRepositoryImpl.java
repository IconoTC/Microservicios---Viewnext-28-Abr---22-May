package com.viewnext.repositories;

import java.util.List;

import com.viewnext.models.Datos;

public class ActorRepositoryImpl implements ActorRepository{

	@Override
	public List<String> findActoresByPelicula(Long id) {
		System.out.println("Metodo findActoresByPelicula de ActorRepositoryImpl");
		return Datos.ACTORES;
	}

}
