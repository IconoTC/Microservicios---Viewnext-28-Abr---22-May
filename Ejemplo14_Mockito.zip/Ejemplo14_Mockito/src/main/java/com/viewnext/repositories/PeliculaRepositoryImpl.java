package com.viewnext.repositories;

import java.util.Arrays;
import java.util.List;

import com.viewnext.models.Pelicula;

public class PeliculaRepositoryImpl implements PeliculaRepository{

	@Override
	public List<Pelicula> findAll() {
		// TODO Auto-generated method stub
		return Arrays.asList(new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La infiltrada"),
				new Pelicula(3L, "La habitacion de al lado"));
	}

}
