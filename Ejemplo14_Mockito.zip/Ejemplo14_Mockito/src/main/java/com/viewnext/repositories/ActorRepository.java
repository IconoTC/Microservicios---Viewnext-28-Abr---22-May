package com.viewnext.repositories;

import java.util.List;

public interface ActorRepository {
	
	List<String> findActoresByPelicula(Long id);

}
