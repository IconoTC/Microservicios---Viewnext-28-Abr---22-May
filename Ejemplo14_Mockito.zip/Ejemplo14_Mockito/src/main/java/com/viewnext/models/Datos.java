package com.viewnext.models;

import java.util.Arrays;
import java.util.List;

public class Datos {
	
	public static List<Pelicula> PELICULAS =  Arrays.asList(new Pelicula(1L, "El 47"),
			new Pelicula(2L, "La infiltrada"),
			new Pelicula(3L, "La habitacion de al lado"));
	
	public static List<String> ACTORES = Arrays.asList("Actor 1", 
			"Actor 2", "Actor 3");

}
