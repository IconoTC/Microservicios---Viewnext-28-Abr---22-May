package com.viewnext.services;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.viewnext.models.Datos;
import com.viewnext.models.Pelicula;
import com.viewnext.repositories.ActorRepository;
import com.viewnext.repositories.ActorRepositoryImpl;
import com.viewnext.repositories.PeliculaRepository;
import com.viewnext.repositories.PeliculaRepositoryImpl;

@ExtendWith(MockitoExtension.class)
public class PeliculaServiceImplTest {
	
	// Para poder llamar a los metodos necesitamos tener la clase y no la interface
	@Mock
	PeliculaRepositoryImpl repository;
	
	@Mock
	ActorRepositoryImpl actorRepository;
	
	@InjectMocks
	PeliculaServiceImpl service;
	
	@Captor
	ArgumentCaptor<Long> captor;
	
	@BeforeEach
	void inicioPrueba() {
		// Creo un mock (objeto ficticio del repository)
		// No se puede crear un mock de cualquier metodo, solo publicos o default
		// nunca de un metodo privado, estatico o final
		//repository = Mockito.mock(PeliculaRepository.class);
		//actorRepository = Mockito.mock(ActorRepository.class);
		//service = new PeliculaServiceImpl(repository, actorRepository);
		
		// Al usar anotaciones necesitamos activarlas:
		// tenemos 2 formas de hacerlo: programatica o con anotacion @ExtendWith
		//MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testFindPeliculaByNombre() {
		//PeliculaRepository repository = new PeliculaRepositoryImpl();
		//PeliculaService service = new PeliculaServiceImpl(repository);
		
		List<Pelicula> datos = Arrays.asList(new Pelicula(1L, "El 47"),
				new Pelicula(2L, "La infiltrada"),
				new Pelicula(3L, "La habitacion de al lado"));
		
		Mockito.when(repository.findAll()).thenReturn(datos);
		
		Pelicula pelicula = service.findPeliculaByNombre("47");
		
		Assertions.assertNotNull(pelicula);
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
	}
	
	@Test
	void testActoresPelicula() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPelicula(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = service.findPeliculaByNombreConActores("La infiltrada");
		
		Assertions.assertEquals(3, pelicula.getActores().size());
	}
	
	// con verify comprobamos que llamamos a determinados metodos del mock
	@Test
	void testActoresPeliculaVerify() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPelicula(2L)).thenReturn(Datos.ACTORES);
		
		Pelicula pelicula = service.findPeliculaByNombreConActores("La infiltrada");
		
		//Assertions.assertEquals(3, pelicula.getActores().size());
		
		Mockito.verify(repository).findAll();
		Mockito.verify(actorRepository).findActoresByPelicula(2L);
	}
	
	@Test
	void testExcepciones() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		Mockito.when(actorRepository.findActoresByPelicula(Mockito.anyLong()))
			.thenThrow(IllegalArgumentException.class);
		
		// Al no tener actores la pelicula lanza una excepcion
		Exception ex = Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.findPeliculaByNombreConActores("La habitacion de al lado");
		});
		
		// Comprobar que la excepcion es IllegalArgumentException
		Assertions.assertEquals(IllegalArgumentException.class, ex.getClass());
	}
	
	
	// Mockito nos ofrece la posibilidad de capturar los argumentos que le pasamos al mock
	// y poder comprobarlos
	// Tenemos 2 formas de hacerlo: ArgumentCaptor o @Captor
	@Test
	void testCapturarArgumentos() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		service.findPeliculaByNombreConActores("La habitacion de al lado");
		
		// Crear una instancia de ArgumentCaptor o una propiedad anotada como @Captor
		// ArgumentCaptor<Long> captor = ArgumentCaptor.forClass(Long.class);
		
		Mockito.verify(actorRepository).findActoresByPelicula(captor.capture());
		Assertions.assertEquals(3L, captor.getValue());
	}
	
	// Spy es una hibrido entre los mocks y los objetos reales
	// Spy no funciona desde interfaces o clases abstractas, ha de ser una clase implementada
	@Test
	void testSpy() {
		PeliculaRepository peliculaRepository = Mockito.spy(PeliculaRepositoryImpl.class);
		ActorRepository actorRepository = Mockito.spy(ActorRepositoryImpl.class);
		PeliculaService peliculaService = new PeliculaServiceImpl(peliculaRepository, actorRepository);
		
		// Sigue llamando al objeto real
		//Mockito.when(actorRepository.findActoresByPelicula(Mockito.anyLong())).thenReturn(Datos.ACTORES);
		
		// Queremos que llame al mock
		Mockito.doReturn(Datos.ACTORES).when(actorRepository).findActoresByPelicula(Mockito.anyLong());
		
		Pelicula pelicula = peliculaService.findPeliculaByNombreConActores("El 47");
		
		Assertions.assertEquals(1L, pelicula.getId());
		Assertions.assertEquals("El 47", pelicula.getNombre());
		Assertions.assertEquals(3, pelicula.getActores().size());
	}
	
	// Probar el order cuando utilizo mas de una peticion
	@Test
	void testOrdenEnMocks() {
		Mockito.when(repository.findAll()).thenReturn(Datos.PELICULAS);
		
		service.findPeliculaByNombreConActores("La Infiltrada");
		service.findPeliculaByNombreConActores("El 47");
		
		InOrder order = Mockito.inOrder(repository, actorRepository);
		order.verify(repository).findAll();
		order.verify(actorRepository).findActoresByPelicula(2L);
		
		order.verify(repository).findAll();
		order.verify(actorRepository).findActoresByPelicula(1L);
	}
	
	
	

}
