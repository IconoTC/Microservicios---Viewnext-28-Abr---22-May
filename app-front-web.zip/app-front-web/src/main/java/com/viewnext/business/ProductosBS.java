package com.viewnext.business;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.viewnext.models.Carrito;
import com.viewnext.models.Producto;

@Service
public class ProductosBS implements ItfzProductosBS{
	
	@Autowired
	private RestTemplate clienteRest;

	@Override
	public List<Producto> obtenerTodos() {
		String URL_BASE = "http://localhost:8091/api/productos/listar";
		
		ResponseEntity<Object[]> responseEntity = clienteRest.getForEntity(URL_BASE, Object[].class);
		Object[] objects = responseEntity.getBody();
		
		ObjectMapper mapper = new ObjectMapper();
		
		return Arrays.stream(objects)
				.map(obj -> mapper.convertValue(obj, Producto.class))
				.collect(Collectors.toList());
	}

	@Override
	public Producto consultarProducto(Long id) {
		String URL_BASE = "http://localhost:8091/api/productos/buscar/{id}";
		return clienteRest.getForObject(URL_BASE, Producto.class, id);
	}

	@Override
	public Carrito consultar(String usuario) {
		String URL_BASE = "http://localhost:8091/api/carrito/consultar/{usuario}";
		return clienteRest.getForObject(URL_BASE, Carrito.class, usuario);
	}

	@Override
	public Carrito crear(String usuario) {
		String URL_BASE = "http://localhost:8091/api/carrito/crear/{usuario}";
		return clienteRest.postForObject(URL_BASE, null, Carrito.class, usuario);
	}

	@Override
	public Carrito agregar(Long id, int cantidad, String usuario) {
		String URL_BASE = "http://localhost:8091/api/carrito/agregarPedido/{id}/cantidad/{cantidad}/usuario/{usuario}";
		clienteRest.put(URL_BASE, null, id, cantidad, usuario);
		return consultar(usuario);
	}

	@Override
	public Carrito eliminar(Long id, String usuario) {
		String URL_BASE = "http://localhost:8091/api/carrito/eliminarPedido/{id}/usuario/{usuario}";
		clienteRest.delete(URL_BASE, id, usuario);
		return consultar(usuario);
	}
	
	

}
