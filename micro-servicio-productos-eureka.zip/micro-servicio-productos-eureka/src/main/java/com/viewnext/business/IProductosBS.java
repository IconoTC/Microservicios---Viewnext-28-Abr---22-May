package com.viewnext.business;

import java.util.List;

import com.viewnext.models.Producto;

public interface IProductosBS {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Long id);

}
