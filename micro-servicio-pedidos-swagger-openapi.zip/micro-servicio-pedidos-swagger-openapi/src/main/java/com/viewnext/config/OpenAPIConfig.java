package com.viewnext.config;

import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class OpenAPIConfig {
	
	public OpenAPI openAPI() {
		return new OpenAPI()
				.info(new Info()
					.title("API de Pedidos")
					.version("1.0")
					.description("Documentacion del micro servicio de pedidos")
				);
	}

}
