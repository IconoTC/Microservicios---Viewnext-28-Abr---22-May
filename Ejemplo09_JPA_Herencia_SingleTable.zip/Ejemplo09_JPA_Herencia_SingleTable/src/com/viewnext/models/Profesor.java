package com.viewnext.models;

import java.io.Serializable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "P")
public class Profesor extends Persona implements Serializable{
	
	private String titulacion;
	
	public Profesor() {
		// TODO Auto-generated constructor stub
	}

	public Profesor(String nombre, String apellido, String titulacion) {
		super(nombre, apellido);
		this.titulacion = titulacion;
	}

	public String getTitulacion() {
		return titulacion;
	}

	public void setTitulacion(String titulacion) {
		this.titulacion = titulacion;
	}

	@Override
	public String toString() {
		return "Profesor [titulacion=" + titulacion + ", toString()=" + super.toString() + "]";
	}
	
	

}
