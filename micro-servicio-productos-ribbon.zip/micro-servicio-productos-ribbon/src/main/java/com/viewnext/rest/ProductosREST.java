package com.viewnext.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.viewnext.business.IProductosBS;
import com.viewnext.models.Producto;

import javax.servlet.http.HttpServletRequest;

@RestController
public class ProductosREST {
	
	// Con puerto dinamico esto no funciona
	// @Value("${server.port}")
	// private Integer port;
	
	// Otra alternativa es inyectar la peticion
	@Autowired
	private HttpServletRequest request;
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(request.getLocalPort());
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) {
		Producto producto = bs.buscarProducto(id);
		producto.setPort(request.getLocalPort());
		return producto;
	}

}
