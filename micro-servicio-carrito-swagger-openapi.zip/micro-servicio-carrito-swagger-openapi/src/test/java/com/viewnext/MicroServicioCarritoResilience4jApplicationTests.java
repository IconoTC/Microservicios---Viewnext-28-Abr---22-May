package com.viewnext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicioCarritoResilience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
