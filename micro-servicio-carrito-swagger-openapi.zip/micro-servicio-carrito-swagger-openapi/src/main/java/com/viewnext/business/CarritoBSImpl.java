package com.viewnext.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.viewnext.clients.PedidosClienteREST;
import com.viewnext.models.Carrito;
import com.viewnext.models.Pedido;
import com.viewnext.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteREST clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		Carrito carrito = consultar(usuario);
		
		// Solo creo el carrito si no existe
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Pedido pedido = clienteFeign.crearPedido(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importePedido = pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(carrito.getImporte() + importePedido);
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		Pedido encontrado = contenido.stream()
				.filter(pedido -> pedido.getProducto().getID() == id)
				.findFirst()
				.get();
		
		contenido.remove(encontrado);
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		return dao.save(carrito);
	}

}














