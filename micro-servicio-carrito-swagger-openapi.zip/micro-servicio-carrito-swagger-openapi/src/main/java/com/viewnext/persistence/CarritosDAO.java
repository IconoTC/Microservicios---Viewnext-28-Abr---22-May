package com.viewnext.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.viewnext.models.Carrito;

@RepositoryRestResource(collectionResourceRel = "CARRITOS", path = "carritos")
public interface CarritosDAO extends MongoRepository<Carrito, String>{
	
	// URL para ver todos los carritos
	// http://localhost:8003/carritos
	
	// http://localhost:8003/carritos/search/findByUsuario?usuario=Pepito
	public Carrito findByUsuario(String usuario);

}
