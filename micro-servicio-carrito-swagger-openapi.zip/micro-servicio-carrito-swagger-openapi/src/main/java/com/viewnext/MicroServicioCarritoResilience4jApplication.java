package com.viewnext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.viewnext.persistence.CarritosDAO;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class MicroServicioCarritoResilience4jApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoResilience4jApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Este metodo se ejecuta cuando ya se ha levantado la app 
		
		// Eliminar todos los datos
		dao.deleteAll();	
	}

}
