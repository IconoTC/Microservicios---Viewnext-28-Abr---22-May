package com.viewnext;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.viewnext.models.Persona;
import com.viewnext.models.PersonaPK;

public class AppMain {
	
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");
		
		EntityManager em = emf.createEntityManager();  // En este momento se abre la conexion a la BBDD
		
		// 1.- Lectura por PK
		PersonaPK pk = new PersonaPK(616111111L, "1111111-A");
		Persona p1 = em.find(Persona.class, pk);
		System.out.println(p1);
		System.out.println("----------------------");
		
		// 2.- Lectura por JPQL
		Query q1 = em.createQuery("select p from Persona p where p.edad > 30");
		List<Persona> mayores = q1.getResultList();
		mayores.forEach(System.out::println); 
		System.out.println("----------------------");
		
		// 3.- Lectura por JPQL NamedQueries
		Query q2 = em.createNamedQuery("nombre");
		q2.setParameter("nom", "Maria");
		System.out.println(q2.getSingleResult());
		System.out.println("----------------------");
		
		Query q3 = em.createNamedQuery("localidad");
		q3.setParameter("loc", "Barcelona");
		System.out.println(q3.getSingleResult());
		System.out.println("----------------------");
		
		// 4.- Ejecutar procedimientos almacenados
		// em.createNamedStoredProcedureQuery("nombre del procedimiento");
		
		// 5.- Ejecutar consultas con SQL
		// em.createNativeQuery("consulta SQL");
			
		// Nos aseguramos de cerrar la conexion
		em.close();
		
	}

}
