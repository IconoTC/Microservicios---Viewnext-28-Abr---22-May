package com.viewnext.models;

public enum EstadoCivil {
	
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO

}
