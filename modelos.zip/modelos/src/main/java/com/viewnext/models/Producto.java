package com.viewnext.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data  // getter, setter, equals, hashCode, toString, constructor vacio y constructor con todos argumentos
@AllArgsConstructor
public class Producto implements Serializable{
	
	private Long ID;
	private String descripcion;
	private double precio;

}
