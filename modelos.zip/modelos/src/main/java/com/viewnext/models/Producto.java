package com.viewnext.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hashCode, toString
@AllArgsConstructor
@NoArgsConstructor
public class Producto{
	
	/*
	 * Para que Lombok funcione se necesita tener instalado en Eclipse el plugin de Lombok
	 */
	
	private Long ID;
	private String descripcion;
	private double precio;

}
