package com.viewnext.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hashCode, toString
@AllArgsConstructor
@NoArgsConstructor
public class Carrito implements Serializable{
	
	@Id
	private String id;
	
	private String usuario;
	private List<Pedido> contenido = new ArrayList<Pedido>();
	private double importe;

}
