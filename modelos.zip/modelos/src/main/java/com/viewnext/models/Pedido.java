package com.viewnext.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pedido implements Serializable{
	
	/*
	 * Para que Lombok funcione se necesita tener instalado en Eclipse el plugin de Lombok
	 * Help / Install new software: Lombok - https://projectlombok.org/p2
	 */
	
	private Producto producto;
	private int cantidad;

}
