package com.viewnext.models;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Pedido implements Serializable{
	
	private Producto producto;
	private int cantidad;

}
