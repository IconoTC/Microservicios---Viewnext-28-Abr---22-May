package com.viewnext.oauth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter{
	
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.tokenStore(tokenStore());
	}
	
	@Override
	public void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests(requests -> requests.antMatchers("/api/security/oauth/**").permitAll()
                .antMatchers(HttpMethod.GET, "/api/productos/listar", "/api/pedidos/crear/{id}/cantidad/{cantidad}",
                        "/api/usuarios/usuarios").permitAll()
                .antMatchers(HttpMethod.GET, "/api/carrito/consultar/{usuario}", "/api/productos/buscar/{id}").hasAnyRole("ADMIN", "USER")
                .antMatchers("/api/productos/**", "/api/pedidos/**", "/api/carrito/**", "/api/usuarios/**").hasRole("ADMIN")
                .anyRequest().authenticated());
			
	}
	
//	@Override
//	public void configure(HttpSecurity http) throws Exception {
//		http.authorizeRequests().antMatchers("/api/security/oauth/**").permitAll()
//			.antMatchers(HttpMethod.GET, "/api/productos/listar", "/api/pedidos/crear/{id}/cantidad/{cantidad}", 
//					"/api/usuarios/usuarios").permitAll()
//			.antMatchers(HttpMethod.GET, "/api/carrito/consultar/{usuario}", "/api/productos/buscar/{id}").hasAnyRole("ADMIN", "USER")
//			.antMatchers("/api/productos/**", "/api/pedidos/**", "/api/carrito/**", "/api/usuarios/**").hasRole("ADMIN")
//			.anyRequest().authenticated();
//			
//	}
	
	@Bean
	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(accessTokenConverter());
	}
	
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		JwtAccessTokenConverter tokenConverter = new JwtAccessTokenConverter();
		tokenConverter.setSigningKey("algun_codigo_secreto");
		return tokenConverter;
	}

}
