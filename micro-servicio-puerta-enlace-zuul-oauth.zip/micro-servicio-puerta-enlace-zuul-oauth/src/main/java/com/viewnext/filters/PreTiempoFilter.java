package com.viewnext.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PreTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Activar o desactivar el filtro
		// Si retorna true -> filtro activado
		// Si retorna false -> filtro desactivado
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Todo el codigo que quiero que se ejecute en este filtro
		
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		// Lo guardo como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.getRequest().setAttribute("tiempoInicio", tiempoInicio);
		
		return null;
	}

	@Override
	public String filterType() {
		// Hay que retornar uno de estos valores: "pre", "post", "route"
		return "pre";
	}

	@Override
	public int filterOrder() {
		// Orden de ejecuccion en el caso de tener mas de un filtro
		return 1;
	}

}
